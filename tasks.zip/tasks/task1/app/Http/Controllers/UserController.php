<?php

namespace App\Http\Controllers;

use App\Models\User;
use Illuminate\Http\Request;
use Carbon\Carbon;
class UserController extends Controller
{
    public function searchData(Request $request)
    {
       $result=User::with('address')
        ->when($request->name != null, function($q) use($request){
            return $q->where('first_name','LIKE','%'.$request->name.'%')
                    ->orWhere('last_name','LIKE','%'.$request->name.'%')
                    ->orWhere('email','LIKE','%'.$request->name.'%') ;
        })
        ->when($request->age != null, function($q) use($request){
            return $q->whereDate('dob', '<=', Carbon::now()->subYears($request->age));
        })
        ->when($request->city != null, function($q) use($request){
            return $q->whereHas('address', function($qu) use($request) {
                $qu->where('city',$request->city);
            });
        })
        ->get();
       return response()->json($result);
    }
}
