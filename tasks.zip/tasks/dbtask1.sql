-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3306
-- Generation Time: Mar 06, 2023 at 03:00 AM
-- Server version: 5.7.36
-- PHP Version: 7.4.26

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `dbtask1`
--

-- --------------------------------------------------------

--
-- Table structure for table `address`
--

DROP TABLE IF EXISTS `address`;
CREATE TABLE IF NOT EXISTS `address` (
  `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `address` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `pincode` int(11) NOT NULL,
  `city` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `state` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `type` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `address_user_id_foreign` (`user_id`)
) ENGINE=MyISAM AUTO_INCREMENT=61 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `address`
--

INSERT INTO `address` (`id`, `user_id`, `address`, `pincode`, `city`, `state`, `type`, `created_at`, `updated_at`) VALUES
(1, 3, '402 Alivia Village\nPort Emelie, IA 38757', 73626, 'Abefort', 'Pennsylvania', 'Office', '2023-03-05 06:05:35', '2023-03-05 06:05:35'),
(2, 4, '9477 Helga Station Apt. 253\nSouth Remington, NM 48666', 627396, 'South Vance', 'Alabama', 'Home', '2023-03-05 06:05:35', '2023-03-05 06:05:35'),
(3, 5, '84843 Sauer Haven Suite 236\nWilltown, MA 37550', 370881, 'Jakubowskimouth', 'Wisconsin', 'Office', '2023-03-05 06:05:35', '2023-03-05 06:05:35'),
(4, 6, '54067 Rene Estates\nSouth Edwardfort, HI 62246-7676', 611652, 'Roweburgh', 'South Dakota', 'Office', '2023-03-05 06:05:35', '2023-03-05 06:05:35'),
(5, 7, '739 Ernser Plains Suite 253\nSouth Jadeton, TN 05241-7689', 372517, 'Port Majorville', 'Oregon', 'Home', '2023-03-05 06:05:35', '2023-03-05 06:05:35'),
(6, 8, '5112 Antonietta Mount\nBergefort, OH 61685', 985485, 'Conroyberg', 'Pennsylvania', 'Office', '2023-03-05 06:05:35', '2023-03-05 06:05:35'),
(7, 9, '967 Louisa Forks Suite 618\nJensenville, NH 47781-5326', 780284, 'West Sister', 'Rhode Island', 'Home', '2023-03-05 06:05:35', '2023-03-05 06:05:35'),
(8, 10, '29281 Herzog Squares\nWest Brionna, VT 63234-9449', 15815, 'Audieport', 'Tennessee', 'Office', '2023-03-05 06:05:35', '2023-03-05 06:05:35'),
(9, 11, '3285 Stiedemann Field\nLake Dominique, KY 98680-3363', 3196, 'Kingside', 'South Carolina', 'Home', '2023-03-05 06:05:35', '2023-03-05 06:05:35'),
(10, 12, '7588 Medhurst Port Apt. 432\nHintzshire, WA 05026', 50298, 'North Golda', 'Florida', 'Home', '2023-03-05 06:05:35', '2023-03-05 06:05:35'),
(11, 13, '586 Dibbert Ways\nLangworthfort, AL 71877-1938', 351482, 'Jastview', 'Mississippi', 'Home', '2023-03-05 06:05:35', '2023-03-05 06:05:35'),
(12, 14, '49435 Heathcote Trail Apt. 029\nMarafort, UT 07970-0934', 213756, 'Lake Myahville', 'Vermont', 'Office', '2023-03-05 06:05:35', '2023-03-05 06:05:35'),
(13, 15, '221 Aiden Radial\nLake Damien, KY 72469-5853', 347249, 'East Turnerton', 'North Carolina', 'Office', '2023-03-05 06:05:35', '2023-03-05 06:05:35'),
(14, 16, '7545 Jackeline Inlet\nParisianland, MA 16859', 599831, 'New Forestside', 'Washington', 'Home', '2023-03-05 06:05:35', '2023-03-05 06:05:35'),
(15, 17, '588 Jolie Course\nSouth Cynthiashire, DC 26937', 311891, 'Port Salvadorchester', 'Oklahoma', 'Office', '2023-03-05 06:05:35', '2023-03-05 06:05:35'),
(16, 18, '90344 Darron Freeway\nHelenville, MT 00613', 806811, 'Legrosville', 'Oklahoma', 'Office', '2023-03-05 06:05:35', '2023-03-05 06:05:35'),
(17, 19, '60234 Darion Circle Suite 314\nWest Beaulahbury, OK 50551', 709857, 'Wymanland', 'New Mexico', 'Home', '2023-03-05 06:05:35', '2023-03-05 06:05:35'),
(18, 20, '506 Jermey Plains\nPort Aliza, ND 70422', 334045, 'Harrisfurt', 'West Virginia', 'Office', '2023-03-05 06:05:35', '2023-03-05 06:05:35'),
(19, 21, '4421 Bins Groves\nSouth Carter, NE 28339-5521', 379610, 'Port Tracey', 'Kentucky', 'Home', '2023-03-05 06:05:35', '2023-03-05 06:05:35'),
(20, 22, '555 Hudson Village\nLeschville, AK 82028', 383555, 'Bednarville', 'South Carolina', 'Office', '2023-03-05 06:05:35', '2023-03-05 06:05:35'),
(21, 23, '2732 Margaret Shore Suite 833\nPort Randi, NH 58607-3735', 662007, 'New Luellafurt', 'Alaska', 'Office', '2023-03-05 06:05:35', '2023-03-05 06:05:35'),
(22, 24, '345 Kyle Parkways Suite 152\nFredafort, NE 02991-9904', 982165, 'Gabrielside', 'Maryland', 'Office', '2023-03-05 06:05:35', '2023-03-05 06:05:35'),
(23, 25, '941 Reina Corners Suite 445\nFrancismouth, MO 94097-2849', 216573, 'Felixland', 'Alaska', 'Home', '2023-03-05 06:05:35', '2023-03-05 06:05:35'),
(24, 26, '573 Oren Ville Apt. 318\nSouth Jaida, VA 64162', 558264, 'Port Chyna', 'Indiana', 'Office', '2023-03-05 06:05:35', '2023-03-05 06:05:35'),
(25, 27, '287 Block Shoals\nColefurt, NY 57086-4130', 312685, 'Maybellefort', 'California', 'Office', '2023-03-05 06:05:35', '2023-03-05 06:05:35'),
(26, 28, '6367 Conroy Station Apt. 412\nNorth Tayabury, AK 97272', 84105, 'Murrayville', 'Hawaii', 'Office', '2023-03-05 06:05:35', '2023-03-05 06:05:35'),
(27, 29, '4675 Sigrid Squares Apt. 947\nRusselview, PA 31042', 458047, 'Port Lanceport', 'Tennessee', 'Home', '2023-03-05 06:05:35', '2023-03-05 06:05:35'),
(28, 30, '530 Wolf Ramp Apt. 934\nWest Milfordview, ME 97400-5291', 72032, 'North Lamarstad', 'New Jersey', 'Office', '2023-03-05 06:05:35', '2023-03-05 06:05:35'),
(29, 31, '6290 Kariane Flats\nIlianaside, VT 97901', 453879, 'South Kyleigh', 'Wyoming', 'Office', '2023-03-05 06:05:35', '2023-03-05 06:05:35'),
(30, 32, '92271 Greenholt Village\nPort Sage, DC 96977', 265826, 'East Emmanuelleport', 'Maine', 'Home', '2023-03-05 06:05:35', '2023-03-05 06:05:35'),
(31, 33, '8844 Gina Greens Apt. 525\nOrphaburgh, WI 59414', 800053, 'North Sylvia', 'Washington', 'Home', '2023-03-05 06:05:35', '2023-03-05 06:05:35'),
(32, 34, '9073 Bradtke Knoll Apt. 075\nNew Lillian, ME 98675', 858730, 'Lake Ransommouth', 'New Jersey', 'Home', '2023-03-05 06:05:35', '2023-03-05 06:05:35'),
(33, 35, '77682 Lon Tunnel Apt. 411\nPort Columbuston, VA 48610-1030', 258972, 'Heloiseview', 'Connecticut', 'Home', '2023-03-05 06:05:35', '2023-03-05 06:05:35'),
(34, 36, '37598 Orie Coves\nLake Pattiebury, NE 41768', 565850, 'North Jayme', 'North Dakota', 'Home', '2023-03-05 06:05:35', '2023-03-05 06:05:35'),
(35, 37, '1523 Hartmann Knolls Suite 214\nRozellamouth, TN 83967', 443442, 'East Emilia', 'Arizona', 'Office', '2023-03-05 06:05:35', '2023-03-05 06:05:35'),
(36, 38, '970 Shanon Landing Suite 549\nD\'angelostad, AK 60833-4520', 84811, 'Mosciskihaven', 'Montana', 'Office', '2023-03-05 06:05:35', '2023-03-05 06:05:35'),
(37, 39, '162 Gaetano Gardens Suite 334\nLake Jamir, ID 94111', 259158, 'McLaughlinside', 'New Mexico', 'Home', '2023-03-05 06:05:35', '2023-03-05 06:05:35'),
(38, 40, '92495 Katelynn Camp\nPort Aiyana, KY 23999-3379', 13618, 'Lake Eleanore', 'Montana', 'Office', '2023-03-05 06:05:35', '2023-03-05 06:05:35'),
(39, 41, '7393 Marcos Mountain Apt. 532\nWest Amberhaven, OR 01513', 221420, 'West Anitaview', 'Arizona', 'Office', '2023-03-05 06:05:35', '2023-03-05 06:05:35'),
(40, 42, '1887 Waelchi Stream\nLake Brantshire, MS 49043-8993', 940149, 'Cormierside', 'Hawaii', 'Office', '2023-03-05 06:05:35', '2023-03-05 06:05:35'),
(41, 43, '495 Bergstrom Parks Suite 640\nTatumton, UT 98461', 84852, 'North Cleve', 'Hawaii', 'Office', '2023-03-05 06:05:35', '2023-03-05 06:05:35'),
(42, 44, '280 Ettie Grove\nWymanhaven, NE 90565-7045', 908507, 'West Leoniemouth', 'Pennsylvania', 'Office', '2023-03-05 06:05:35', '2023-03-05 06:05:35'),
(43, 45, '1433 Pollich Alley\nWiegandtown, GA 53544-4271', 776894, 'South Sidney', 'Missouri', 'Office', '2023-03-05 06:05:35', '2023-03-05 06:05:35'),
(44, 46, '803 Ahmed Pass\nAlysabury, NJ 22337-4595', 727227, 'Rosalindmouth', 'Arizona', 'Office', '2023-03-05 06:05:35', '2023-03-05 06:05:35'),
(45, 47, '23065 Andy Skyway Suite 762\nNorth Kimberly, OK 98404-3298', 279129, 'Windlerburgh', 'New Jersey', 'Home', '2023-03-05 06:05:35', '2023-03-05 06:05:35'),
(46, 48, '212 Annalise Harbor\nFaemouth, SD 98811', 336895, 'New Gabriellaview', 'Nebraska', 'Office', '2023-03-05 06:05:35', '2023-03-05 06:05:35'),
(47, 49, '3811 Toby Harbor Apt. 866\nKundeshire, GA 74367-6851', 898711, 'New Rhett', 'North Carolina', 'Office', '2023-03-05 06:05:35', '2023-03-05 06:05:35'),
(48, 50, '8695 Hyatt Drives Suite 157\nNew Arnoldoview, NC 75459', 377068, 'Port Rebaburgh', 'California', 'Home', '2023-03-05 06:05:35', '2023-03-05 06:05:35'),
(49, 51, '3081 Ruthie Forges\nHerzogbury, VA 77374-3182', 60467, 'New Kaia', 'Hawaii', 'Home', '2023-03-05 06:05:35', '2023-03-05 06:05:35'),
(50, 52, '1661 Gutmann Fort Suite 395\nVicentaborough, IL 10365', 482086, 'Jenkinsmouth', 'Mississippi', 'Office', '2023-03-05 06:05:35', '2023-03-05 06:05:35'),
(51, 53, '81267 Lula Gateway Suite 967\nNew Arnotown, MS 68642-1110', 842915, 'Lake Julio', 'Montana', 'Home', '2023-03-05 06:05:35', '2023-03-05 06:05:35'),
(52, 54, '13191 Kovacek Courts\nDaishachester, IL 32482-9107', 861624, 'Felixstad', 'Minnesota', 'Office', '2023-03-05 06:05:35', '2023-03-05 06:05:35'),
(53, 55, '8218 Yvonne Cliffs\nTodbury, OR 17345', 892566, 'Rockystad', 'Wisconsin', 'Office', '2023-03-05 06:05:35', '2023-03-05 06:05:35'),
(54, 56, '6666 Annie Drive Suite 625\nBergechester, NJ 71222', 427782, 'Josieborough', 'South Carolina', 'Office', '2023-03-05 06:05:35', '2023-03-05 06:05:35'),
(55, 57, '579 Jermey Extension Suite 113\nAbernathybury, FL 97626-4554', 605619, 'East Bulahchester', 'Michigan', 'Home', '2023-03-05 06:05:35', '2023-03-05 06:05:35'),
(56, 58, '59829 Braun Isle\nGenovevaville, NC 14160', 152212, 'Toniville', 'Michigan', 'Home', '2023-03-05 06:05:35', '2023-03-05 06:05:35'),
(57, 59, '88704 Collier Fall Apt. 531\nNorth Annetteville, AZ 48280', 317613, 'East Carlo', 'Virginia', 'Office', '2023-03-05 06:05:35', '2023-03-05 06:05:35'),
(58, 60, '992 Dorian Summit\nEast Alexanderville, OR 44498', 359505, 'Jacquelynberg', 'Kentucky', 'Home', '2023-03-05 06:05:35', '2023-03-05 06:05:35'),
(59, 61, '75557 Leonie Rapids Suite 063\nKamilleborough, WA 98341-9460', 682658, 'West Amya', 'Pennsylvania', 'Home', '2023-03-05 06:05:35', '2023-03-05 06:05:35'),
(60, 62, '27772 Retha Cliff Apt. 576\nKathlynstad, UT 26396', 896508, 'Mayerborough', 'Texas', 'Office', '2023-03-05 06:05:35', '2023-03-05 06:05:35');

-- --------------------------------------------------------

--
-- Table structure for table `failed_jobs`
--

DROP TABLE IF EXISTS `failed_jobs`;
CREATE TABLE IF NOT EXISTS `failed_jobs` (
  `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
  `uuid` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `connection` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `queue` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `payload` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `exception` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `failed_jobs_uuid_unique` (`uuid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `migrations`
--

DROP TABLE IF EXISTS `migrations`;
CREATE TABLE IF NOT EXISTS `migrations` (
  `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT,
  `migration` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `migrations`
--

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(1, '2014_10_12_000000_create_users_table', 1),
(2, '2014_10_12_100000_create_password_resets_table', 1),
(3, '2019_08_19_000000_create_failed_jobs_table', 1),
(4, '2019_12_14_000001_create_personal_access_tokens_table', 1),
(5, '2023_03_05_070703_create_address_table', 1);

-- --------------------------------------------------------

--
-- Table structure for table `password_resets`
--

DROP TABLE IF EXISTS `password_resets`;
CREATE TABLE IF NOT EXISTS `password_resets` (
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  KEY `password_resets_email_index` (`email`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `personal_access_tokens`
--

DROP TABLE IF EXISTS `personal_access_tokens`;
CREATE TABLE IF NOT EXISTS `personal_access_tokens` (
  `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
  `tokenable_type` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `tokenable_id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(64) COLLATE utf8mb4_unicode_ci NOT NULL,
  `abilities` text COLLATE utf8mb4_unicode_ci,
  `last_used_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `personal_access_tokens_token_unique` (`token`),
  KEY `personal_access_tokens_tokenable_type_tokenable_id_index` (`tokenable_type`,`tokenable_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
CREATE TABLE IF NOT EXISTS `users` (
  `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT,
  `first_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `last_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `mobile_number` varchar(10) COLLATE utf8mb4_unicode_ci NOT NULL,
  `dob` date DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_email_unique` (`email`),
  UNIQUE KEY `users_mobile_number_unique` (`mobile_number`)
) ENGINE=MyISAM AUTO_INCREMENT=63 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `first_name`, `last_name`, `email`, `mobile_number`, `dob`, `created_at`, `updated_at`) VALUES
(1, 'Jazmyn', 'Hudson', 'harvey.cathrine@example.org', '4353368099', '1979-04-21', '2023-03-05 06:01:22', '2023-03-05 06:01:22'),
(2, 'Donny', 'Dach', 'lennie43@example.org', '7723288441', '2020-11-11', '2023-03-05 06:03:11', '2023-03-05 06:03:11'),
(3, 'Cristina', 'Abernathy', 'esther.cremin@example.net', '3745886890', '1981-05-15', '2023-03-05 06:05:35', '2023-03-05 06:05:35'),
(4, 'Velva', 'Kautzer', 'sstiedemann@example.net', '5691094208', '2005-02-26', '2023-03-05 06:05:35', '2023-03-05 06:05:35'),
(5, 'Dena', 'Adams', 'theodora.boyle@example.net', '3007183304', '2001-02-27', '2023-03-05 06:05:35', '2023-03-05 06:05:35'),
(6, 'Guadalupe', 'Von', 'brendon.rogahn@example.com', '4409669867', '2003-04-09', '2023-03-05 06:05:35', '2023-03-05 06:05:35'),
(7, 'Demetrius', 'Davis', 'buster.murazik@example.org', '6452298248', '1996-07-05', '2023-03-05 06:05:35', '2023-03-05 06:05:35'),
(8, 'Maurice', 'Smith', 'aliza57@example.net', '6539536131', '2001-10-16', '2023-03-05 06:05:35', '2023-03-05 06:05:35'),
(9, 'Donnie', 'Abernathy', 'darion.schultz@example.net', '9289597719', '2018-06-08', '2023-03-05 06:05:35', '2023-03-05 06:05:35'),
(10, 'David', 'Nolan', 'beahan.zelma@example.com', '3756328620', '1996-05-02', '2023-03-05 06:05:35', '2023-03-05 06:05:35'),
(11, 'Ivah', 'Mante', 'sim79@example.net', '4231333896', '1998-03-10', '2023-03-05 06:05:35', '2023-03-05 06:05:35'),
(12, 'Aubrey', 'Hoppe', 'esteban.graham@example.com', '9484737907', '2004-04-14', '2023-03-05 06:05:35', '2023-03-05 06:05:35'),
(13, 'Cristobal', 'Howe', 'terrell00@example.net', '5289517232', '1978-11-05', '2023-03-05 06:05:35', '2023-03-05 06:05:35'),
(14, 'Anne', 'Hane', 'marcellus34@example.com', '5633707906', '2006-03-18', '2023-03-05 06:05:35', '2023-03-05 06:05:35'),
(15, 'Billy', 'Hermann', 'alessia52@example.org', '2996775544', '2012-07-30', '2023-03-05 06:05:35', '2023-03-05 06:05:35'),
(16, 'Genoveva', 'Wilkinson', 'madelynn76@example.net', '7486077961', '2002-04-06', '2023-03-05 06:05:35', '2023-03-05 06:05:35'),
(17, 'Bennett', 'Prosacco', 'julien.reichert@example.net', '7260393014', '1980-06-27', '2023-03-05 06:05:35', '2023-03-05 06:05:35'),
(18, 'Nola', 'Lindgren', 'considine.reed@example.net', '8079386232', '1988-10-04', '2023-03-05 06:05:35', '2023-03-05 06:05:35'),
(19, 'Trace', 'Terry', 'kschinner@example.org', '5995727856', '2008-01-02', '2023-03-05 06:05:35', '2023-03-05 06:05:35'),
(20, 'Madeline', 'Kreiger', 'opaucek@example.net', '9523207004', '2010-03-31', '2023-03-05 06:05:35', '2023-03-05 06:05:35'),
(21, 'Trycia', 'Hintz', 'nlang@example.net', '0924358629', '2013-04-15', '2023-03-05 06:05:35', '2023-03-05 06:05:35'),
(22, 'Ernie', 'Kutch', 'wilkinson.angelita@example.net', '8561380914', '2014-06-16', '2023-03-05 06:05:35', '2023-03-05 06:05:35'),
(23, 'Rosella', 'Orn', 'bartell.leonora@example.org', '6565874939', '1984-09-05', '2023-03-05 06:05:35', '2023-03-05 06:05:35'),
(24, 'Remington', 'Fadel', 'kaylah82@example.net', '2247862689', '2015-01-22', '2023-03-05 06:05:35', '2023-03-05 06:05:35'),
(25, 'Elliott', 'Ritchie', 'qleuschke@example.net', '5598234876', '1976-11-15', '2023-03-05 06:05:35', '2023-03-05 06:05:35'),
(26, 'Stanley', 'Jacobs', 'abbie81@example.org', '7559526930', '2005-06-06', '2023-03-05 06:05:35', '2023-03-05 06:05:35'),
(27, 'Fern', 'Tromp', 'efrain.oconner@example.com', '7755228342', '1986-07-22', '2023-03-05 06:05:35', '2023-03-05 06:05:35'),
(28, 'Maia', 'Yost', 'fwhite@example.com', '9844336409', '1982-04-06', '2023-03-05 06:05:35', '2023-03-05 06:05:35'),
(29, 'Lavinia', 'Jakubowski', 'akeem.trantow@example.net', '1283394300', '2016-11-28', '2023-03-05 06:05:35', '2023-03-05 06:05:35'),
(30, 'Jorge', 'Pfannerstill', 'jamison.deckow@example.com', '2635634804', '2007-04-05', '2023-03-05 06:05:35', '2023-03-05 06:05:35'),
(31, 'Silas', 'Cormier', 'aracely.spinka@example.org', '5922195315', '1999-10-09', '2023-03-05 06:05:35', '2023-03-05 06:05:35'),
(32, 'Asha', 'Rau', 'nframi@example.com', '2107790595', '1971-02-04', '2023-03-05 06:05:35', '2023-03-05 06:05:35'),
(33, 'Ivory', 'Hickle', 'clara.mante@example.net', '7548246072', '1977-01-28', '2023-03-05 06:05:35', '2023-03-05 06:05:35'),
(34, 'Harry', 'Wisoky', 'fmarvin@example.com', '8460821089', '1990-04-09', '2023-03-05 06:05:35', '2023-03-05 06:05:35'),
(35, 'Alberto', 'Zemlak', 'karlee.cummings@example.com', '8450253564', '2016-09-01', '2023-03-05 06:05:35', '2023-03-05 06:05:35'),
(36, 'Tomas', 'Corwin', 'reinger.elinore@example.net', '6902617351', '2010-10-17', '2023-03-05 06:05:35', '2023-03-05 06:05:35'),
(37, 'Elda', 'Von', 'halle23@example.net', '7657408572', '2021-06-04', '2023-03-05 06:05:35', '2023-03-05 06:05:35'),
(38, 'Valentina', 'Bartell', 'roosevelt47@example.net', '0841893140', '1980-11-11', '2023-03-05 06:05:35', '2023-03-05 06:05:35'),
(39, 'Reva', 'Schamberger', 'uweimann@example.org', '9243000387', '2015-12-28', '2023-03-05 06:05:35', '2023-03-05 06:05:35'),
(40, 'Loma', 'Homenick', 'clark.cruickshank@example.org', '7734990167', '1973-05-04', '2023-03-05 06:05:35', '2023-03-05 06:05:35'),
(41, 'Brendan', 'Willms', 'roselyn65@example.com', '4252434089', '1992-04-15', '2023-03-05 06:05:35', '2023-03-05 06:05:35'),
(42, 'Hettie', 'Cummings', 'jolie40@example.net', '3743470055', '1993-07-29', '2023-03-05 06:05:35', '2023-03-05 06:05:35'),
(43, 'Kathryn', 'Pollich', 'stanton.titus@example.com', '4772029293', '2006-07-13', '2023-03-05 06:05:35', '2023-03-05 06:05:35'),
(44, 'Jess', 'Eichmann', 'chester.botsford@example.net', '5906112311', '1989-08-06', '2023-03-05 06:05:35', '2023-03-05 06:05:35'),
(45, 'Wilmer', 'Kautzer', 'colt98@example.org', '5721467372', '1973-10-29', '2023-03-05 06:05:35', '2023-03-05 06:05:35'),
(46, 'Christy', 'Hartmann', 'monserrat01@example.net', '2990857329', '1989-06-27', '2023-03-05 06:05:35', '2023-03-05 06:05:35'),
(47, 'Ima', 'Stamm', 'rafael.price@example.com', '7586238852', '2003-10-27', '2023-03-05 06:05:35', '2023-03-05 06:05:35'),
(48, 'Haylie', 'Bernier', 'gquigley@example.com', '1540127201', '1991-01-20', '2023-03-05 06:05:35', '2023-03-05 06:05:35'),
(49, 'Anissa', 'Stanton', 'sauer.olin@example.com', '3753145037', '2007-02-16', '2023-03-05 06:05:35', '2023-03-05 06:05:35'),
(50, 'Krystina', 'Schoen', 'maiya54@example.org', '6040417180', '2016-08-03', '2023-03-05 06:05:35', '2023-03-05 06:05:35'),
(51, 'Alana', 'Rohan', 'cbergstrom@example.net', '5165852575', '1974-06-17', '2023-03-05 06:05:35', '2023-03-05 06:05:35'),
(52, 'Alison', 'Tillman', 'jacynthe.berge@example.com', '9129867349', '2002-03-26', '2023-03-05 06:05:35', '2023-03-05 06:05:35'),
(53, 'Palma', 'Muller', 'dakota.gerlach@example.org', '7734005477', '2010-02-04', '2023-03-05 06:05:35', '2023-03-05 06:05:35'),
(54, 'Antonina', 'Luettgen', 'moore.darian@example.com', '6794746177', '1990-05-16', '2023-03-05 06:05:35', '2023-03-05 06:05:35'),
(55, 'Kaley', 'Stanton', 'deonte.sanford@example.com', '3076734264', '1994-10-20', '2023-03-05 06:05:35', '2023-03-05 06:05:35'),
(56, 'Micaela', 'Moen', 'ywilderman@example.org', '9106615536', '2016-01-02', '2023-03-05 06:05:35', '2023-03-05 06:05:35'),
(57, 'Kevin', 'Hand', 'terry09@example.net', '0961807405', '2019-07-15', '2023-03-05 06:05:35', '2023-03-05 06:05:35'),
(58, 'Rashawn', 'Macejkovic', 'dwalsh@example.org', '4888972387', '1975-01-09', '2023-03-05 06:05:35', '2023-03-05 06:05:35'),
(59, 'Crystal', 'Hamill', 'umonahan@example.net', '7868885219', '2002-02-14', '2023-03-05 06:05:35', '2023-03-05 06:05:35'),
(60, 'Rebeka', 'Hermann', 'oschroeder@example.org', '4216267522', '2006-05-02', '2023-03-05 06:05:35', '2023-03-05 06:05:35'),
(61, 'Ettie', 'Padberg', 'clarissa.gibson@example.net', '7722878574', '2008-05-04', '2023-03-05 06:05:35', '2023-03-05 06:05:35'),
(62, 'Darrell', 'Thiel', 'macy06@example.com', '7569037466', '2006-04-11', '2023-03-05 06:05:35', '2023-03-05 06:05:35');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
