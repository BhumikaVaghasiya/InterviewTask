<?php
$size = 5; // the size of the diamond pattern
$alpha = range('A', 'Z');  
// loop for the upper half of the diamond
for ($i = 1; $i <= $size; $i++) {
    for($sp = 1; $sp <= $size-$i; $sp++)
    {
        echo "&nbsp;&nbsp;&nbsp;";  
    }
    $temp=1;
    for($j = 1; $j <= $i; $j++)
    {
        echo $temp."&nbsp;";
        $temp=$temp+2;
    }
    for($k = 0; $k < $i-1; $k++)
    {
        echo $alpha[$k]." ";  
    }
    echo "<br>";
}
// loop for the bottom half of the diamond
for ($i = $size-1; $i >= 1; $i--) {
    for($sp = $size; $sp > $i; $sp--)
    {
        echo "&nbsp;&nbsp;&nbsp;";  
    }
    $temp=1;
    for($j = 1; $j <= $i; $j++)
    {
        echo $temp."&nbsp;";
        $temp=$temp+2;
    }
    for($k = 0; $k < $i-1; $k++)
    {
        echo $alpha[$k]." ";  
    }
    echo "<br>";
}
?>
